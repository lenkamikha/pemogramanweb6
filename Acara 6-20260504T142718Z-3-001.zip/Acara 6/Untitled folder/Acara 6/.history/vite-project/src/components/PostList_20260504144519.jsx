import { useEffect, useState } from "react";
import axiosInstance from "../api/axiosInstance";

function PostList() {
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    axiosInstance.get("/posts")
      .then(res => setPosts(res.data))
      .catch(err => console.log(err));
  }, []);

  return (
    <div>
      <h2>Data Posts</h2>
      {posts.slice(0, 10).map(post => (
        <div key={post.id}>
          <h4>{post.title}</h4>
          <p>{post.body}</p>
          <hr />
        </div>
      ))}
    </div>
  );
}

export default PostList;
