import { useEffect, useState } from "react";
import axiosInstance from "../api/axiosInstance";

function UserList() {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    axiosInstance.get("/users")
      .then(res => setUsers(res.data))
      .catch(err => console.log(err));
  }, []);

  return (
    <div>
      <h2>Data User</h2>
      {users.map(user => (
        <p key={user.id}>{user.name}</p>
      ))}
    </div>
  );
}

export default UserList;
