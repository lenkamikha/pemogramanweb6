import UserList from "./components/UserList";
import PostList from "./components/PostList";

function App() {
  return (
    <div>
      <UserList />
      <PostList />
    </div>
  );
}

export default App;
